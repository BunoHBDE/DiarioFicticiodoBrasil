export interface Article {
  headline: string;
  category: string;
  summary: string;
  body: string;
  imageUrl: string;
}