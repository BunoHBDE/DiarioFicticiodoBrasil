
export const CATEGORIES = ["Nacional", "Esportes", "Economia", "Cultura", "Tecnologia", "Internacional"];
